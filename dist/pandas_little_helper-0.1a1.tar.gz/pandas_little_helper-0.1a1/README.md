# Pandas Little Helper
As part of a data sciense course I took, I've created a nice list of tools, that I found usefull. I think you can enjoy them too. I've decided that the right thing to do is publish them to help you with your data sciense journy

## Warning
This module is still in alpha stages, and should not be used in production. Expect no backward 
compatibility at this point

## License
This package is released with GPL 3 for private and commertial use.

## How to install
I don't know. This is the first package I'm trying to build. I promise I'll get back to you when I can

## How to contribute
All contributions must follow the following guidelines:
1. All module code Must pass with 100% mypy.
2. All "type: ignore" comments have to be precided with a comment explaining it
3. All module code Must pass pylint with 10/10
4. All functionalities must have a pytest unittest. Test can ignore pylint and mypy rules
5. All tests must pass

To contribute Just follow these instructions.
(https://www.dataschool.io/how-to-contribute-on-github/)

## How to I talk to you?
guruyaya@gmail.com