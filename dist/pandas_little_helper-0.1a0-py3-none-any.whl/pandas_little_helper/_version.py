""" Version file
"""
__version__ = '0.1a0'
